//form validation
  var userName;
  userName = prompt("Please enter your name");
  document.write("<h3>Hello! welcome to our page " + userName + "</h3>");
//  -->

    function validateForm() {
    if (document.forms[0].userName.value == "" )
    {
    alert("Name field cannot be empty.");
    return false;
} // end if
if (document.forms[0].Email.value =="") {
    alert("email field cannot be empty.");
    return false;
} // end if

} // end function validateForm
//  -->
